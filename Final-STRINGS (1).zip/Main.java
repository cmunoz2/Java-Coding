//    Check Email
// Cesar Munoz 12/10/2019

/*

At your organization, email addresses contain an @ and acme.com.  For example, JohnDoe@acme.com. 

Write an application named CheckEmail that asks a user to enter an email address and determines whether it is a valid. If the email address is not valid, display an example of a valid email address.

*/

import java.util.regex.Matcher; 
import java.util.regex.Pattern; 
import java.util.Scanner;
  
class Main 
{ 
    public static boolean isValid(String email) 
    { 
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                            "[a-zA-Z0-9_+&*-]+)*@acme.com";
                              
        Pattern pat = Pattern.compile(emailRegex); 
        if (email == null) 
            return false; 
        return pat.matcher(email).matches(); 
    } 
  
    // driver function to check 
    public static void main(String[] args) 
    { 
        
        Scanner scnr = new Scanner(System.in);
        System.out.println("Input an email using 'acme.com'.");
        String email = scnr.next();

        
          if (isValid(email)){ 
            System.out.print("Accepted!");
          }
          else{
            System.out.println("Invalid...");
            System.out.println("Use '@acme.com' to create a valid email.");
            System.out.println("Example123@acme.com");
          }
        
    } 
} 
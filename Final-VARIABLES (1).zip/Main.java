//    House Painting
// Cesar Munoz 12/10/2019

/* 

Prompt a user for the length and height of the 4 interior walls scheduled to be painted for this job. Also prompt the user for the length and width of the door and the 2 windows in the room. The door and windows will not be painted.

The room will need 2 coats of paint. 
Cost of a gallon of paint = $20.00
1 gallon covers 200 square feet (sqft = length x width).
You charge $5 per square foot. 
Display the total square feet to be painted (minus door and windows).
Display the total paint used.
Display the total expected profit.

*/

import java.util.Scanner;

import java.text.NumberFormat;

class Main {
  public static void main(String[] args) 
  {

    // Variables
    double numGallon;
    double gallonCost = 20;
    double ttlPaintUsed;
    double ttlProfit;

    int wallLength;
    int wallWidth;

    int doorLen;
    int doorWid;

    int windowLen;
    int windowWid;

    int wallTotal;
    int doorTotal;
    int windowTotal;

    //Scanner, in order to receive User Info.
    Scanner scnr = new Scanner(System.in);
    //NumberFormat, in order to convert profit to currency when displaying.
    NumberFormat formatter = NumberFormat.getCurrencyInstance();


    //Program Begins
    System.out.println("Hello, User...");
    
    System.out.println("Input a LENGTH for FOUR interior WALLS.");
    wallLength = scnr.nextInt();

    System.out.println("Good. Now, input a WIDTH for those same WALLS.");
    wallWidth = scnr.nextInt();

    System.out.println("Did I mention that there will also be a *Door* and Two *Windows*?");
    System.out.println("Firstly, the DOOR LENGTH.");
    doorLen = scnr.nextInt();

    System.out.println("And the DOOR WIDTH?");
    doorWid = scnr.nextInt();

    System.out.println("Lastly, the WINDOWS.");
    System.out.println("WINDOW LENGTH?");
    windowLen = scnr.nextInt();

    System.out.println("And the WINDOW WIDTH?");
    windowWid = scnr.nextInt();


    //Program Mathematics
    wallTotal = (wallLength * wallWidth) * 4;
    doorTotal = (doorLen * doorWid);
    windowTotal = (windowLen * windowWid) * 2;

    ttlPaintUsed = (wallTotal - (doorTotal + windowTotal)) * 2;

    numGallon = ttlPaintUsed / 200.0;
    numGallon = ((int) Math.ceil(numGallon));
 
    ttlProfit = ((ttlPaintUsed / 2) * 5) - (numGallon * gallonCost);

    //Program Output
    System.out.println("The amount of total square feet: " + (ttlPaintUsed/2));
    System.out.println("The amount of total paint used: " + ttlPaintUsed);
    System.out.println("The amount of total profit made: " + formatter.format(ttlProfit));
  }
}
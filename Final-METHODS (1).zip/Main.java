//    Phone Chat Average
// Cesar Munoz 12/10/2019

/*

From the previous app, write a program named PhoneChatAvg that prompts the user to enter six 10 digit phone numbers and the number of minutes for each call.  Store the phone numbers and minutes in a Collection. Display the report at the end of the app but also add a method called CallAverage which will display the average length of phone call from the list of 10 calls.  

E.g.

Phone Number                 Minutes

3168459685                       22

6168459665                       111

7168459685                       242

The average length of a call was 38 minutes.

*/

import java.io.*; 
import java.util.*;

class Main {
  public static void main(String[] args) {

    System.out.println("You will give 6 phone numbers as well as how long the phone call lasted.");

    ArrayList<Integer> phoneNumbers = new ArrayList<Integer>();
    ArrayList<Integer> minList = new ArrayList<Integer>();
    Scanner scnr = new Scanner(System.in);
    int userNum;
    
    

    //Add both phone numbers AND Minutes and THEN display, all together.
    for (int i = 0; i < 6; i++){
 
      System.out.println("Insert a phone number (10 digits)");
      userNum = scnr.nextInt();
      phoneNumbers.add(userNum);

      
      System.out.println("And how long this number was on the line in minutes.");
      userNum = scnr.nextInt();
      minList.add(userNum);
    }
    System.out.println(" ");

    System.out.println("phoneNumbers    Minutes");
    for (int i = 0 ; i < 6; i++) {
    System.out.printf("%d     %d\n", phoneNumbers.get(i), minList.get(i));
    }

    double total = 0;
    for(int i=0; i < 6; i++)
    {
      total = total + minList.get(i);
    }

    double average = total / 6;

    System.out.format("The average time spent on the phone was: %.3f", average);
  }
}
// !! UNFINISHED !!


//    Sales Leader
// Cesar Munoz 12/10/2019

/*

Create an application named SalesLeader.

Add a class to your project called SalesPerson.

The SalesPerson class contains the following Properties:

FirstName - The salesperson's firs name (as a string)

SalesAmount - The sales amount ( as a double)

SalesArea - The 3 areas are the enumeration West Coast, MidWest, and East Coast.

Add a constructor which sets FirstName to "None", SalesAmount to 0 and SalesArea to MidWest.

Add a method which checks if the SalesAmount is greater than $100,000.  If so, add 10% to the SalesAmount.

In the main class (Default Class created), create the following:

Create 3 objects from SalesPerson.

                salesperson1

                salesperson2

                salesperson3

Prompt the user to set the amount of sales, first name and sales area for each object. 

Display the name, sales amount and area for each sales person.  Display which sales person is the Sales Leader this month and their commission (15% of total sales) … but first, add a method SalesLeaderTie to Program class to check if there might be a tie for Sales Leader. 

*/

import java.io.*; 
import java.util.*;

//Object Class
class salesLeader {
  String firstName;
  double salesAmount;
 //Enumeration 
 enum salesArea
  {
    WCoast, MidWest, ECoast
  }
  //constructor
  salesLeader(String name, double amount, salesArea any) {
    this.firstName = "none";
    this.salesAmount = 0;
    this.salesArea = MidWest;
  }   
  public static void checkSAmount(double salesAmount) 
  {
  if (salesAmount > 100000) 
  {
    double salesAmountMth = salesAmount + (salesAmount*(10.0f/100.0f)); 
    salesAmount = salesAmountMth;
  } 
  }

  public static void salesTie (){
    //tie method
    //...
  }
}


//Main Code
class Main {
  public static void main(String[] args) {
    salesLeader salesLeader1 = new salesLeader("Bob", 10002, MidWest);
    salesLeader salesLeader2 = new salesLeader("Jennifer", 53229, WCoast);
    salesLeader salesLeader3 = new salesLeader("Pachellihoocho", 200000, ECoast);
    //Display all adjectives for each class object
    //...

    //Area where testing for which salesLeader has the highest sales
    //if (salesLeader1(amount) > salesLeader2(amount)){}
    //...
    //display highest sales
    //...
  }
}


//    Loop Email
//Cesar Munoz 12/10/2019

/*

At your organization, email addresses contain an @ and acme.com.  For example, JohnDoe@acme.com.  For other types of email, the will only need to contain the @ and three letter extension.  For example, myhome@cox.net.

Write an application named LoopEmail that uses a loop to ask a user to enter a work, gmail (must use @gmail) and home email address. Determine whether the work, gmail and home email address is a valid. If the email address is not valid, display an example of a valid email address.

*/

import java.util.regex.Matcher; 
import java.util.regex.Pattern; 
import java.util.Scanner;

class Main {
    public static boolean isValid1(String userWork) 
    { 
        String emailWork = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                            "[a-zA-Z0-9_+&*-]+)*@acme.com";
                              
        Pattern pat = Pattern.compile(emailWork); 
        if (userWork == null) 
            return false; 
        return pat.matcher(userWork).matches(); 
    } 
    public static boolean isValid2(String userGmail) 
    { 
        String emailGmail = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                            "[a-zA-Z0-9_+&*-]+)*@gmail.com";
                              
        Pattern pat = Pattern.compile(emailGmail); 
        if (userGmail == null) 
            return false; 
        return pat.matcher(userGmail).matches(); 
    } 
    public static boolean isValid3(String userPersonal) 
    { 
        String emailPersonal = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                            "[a-zA-Z0-9_+&*-]+)*@" + 
                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                            "A-Z]{2,7}$";
                              
        Pattern pat = Pattern.compile(emailPersonal); 
        if (userPersonal == null) 
            return false; 
        return pat.matcher(userPersonal).matches(); 
    } 

    public static void main(String[] args) {
    String userWork = " ";
    String userGmail = " ";
    String userPersonal = "asd";
    Scanner scnr = new Scanner(System.in);
    
    while(!isValid1(userWork))
    {
      System.out.println("Input an email using 'acme.com'.");
      userWork = scnr.next();
    
      if (isValid1(userWork))
      { 
        System.out.println("Accepted!");
      }
      else
      {
        System.out.println("Invalid...");
        System.out.println("Use '@acme.com' to create a valid email.");
        System.out.println("Example123@acme.com");
      }
    }
    while(!isValid2(userGmail))
    {
      System.out.println("Input an email using 'gmail.com'.");
      userGmail = scnr.next();
    
      if (isValid2(userGmail))
      { 
        System.out.println("Accepted!");
      }
      else
      {
        System.out.println("Invalid...");
        System.out.println("Use '@gmail.com' to create a valid email.");
        System.out.println("Example123@gmail.com");
      }
    }
    while(!isValid3(userPersonal))
    {
      System.out.println("Input any personal email.");
      userPersonal = scnr.next();
    
      if (isValid3(userPersonal))
      { 
        System.out.println("Accepted!");
      }
      else
      {
        System.out.println("Invalid...");
        System.out.println("Example123@XXX.XXX");
      }
    }
    System.out.println();
    System.out.println("Work: " + userWork);
    System.out.println("Gmail: " + userGmail);
    System.out.println("Personal: " + userPersonal);
  }
}
